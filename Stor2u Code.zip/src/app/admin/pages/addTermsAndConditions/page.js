import TermsAndConditionsPage from './addTermsAndconditions'
export default function MainTermsAndConditionsPage(){
    return(
        <>
        <TermsAndConditionsPage/>
        </>
    )
}