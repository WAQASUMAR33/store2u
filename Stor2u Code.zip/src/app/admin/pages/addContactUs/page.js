import ContactUs from './addcontactus'

export default function MainContactUs(){
    return(
        <>
        <ContactUs/>
        </>
    )
}