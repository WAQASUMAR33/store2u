import ReturnAndExchangePolicy from './addReturnAndExchangePolicyPage'

export default function MainReturnAndExchangePolicyPage(){
    return(
        <>
        <ReturnAndExchangePolicy/>
        </>
    )
}