'use client'
import BlogCategories from "./AddBlogCategory";

export default function Blogs() {
  return (
    <>
      <BlogCategories/>
    </>
  );
}
