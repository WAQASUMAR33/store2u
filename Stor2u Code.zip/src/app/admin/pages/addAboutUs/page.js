import AboutUs from './addaboutus'

export default function MainAboutUs(){
    return(
        <>
        <AboutUs/>
        </>
    )
}