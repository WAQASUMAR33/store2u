import PrivacyPolicyPage from './addprivacy'
export default function MainPrivacyPolicyPage(){
    return(
        <>
        <PrivacyPolicyPage/>
        </>
    )
}