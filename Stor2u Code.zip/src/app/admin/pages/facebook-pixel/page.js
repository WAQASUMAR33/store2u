'use client';

import FilterableTable from "./FilterableTable";

// import React from 'react';
// import FilterableTable from './Filterabletable';
// import FilterableTable from '../FilterableTable';  // Adjust path according to your folder structure

const FacebookPixelManagementPage = () => {
  return (
    <div className="container mx-auto py-8">
      
      <FilterableTable/>
    </div>
  );
};

export default FacebookPixelManagementPage;
