import ShippingPolicyPage from './addShippingPolicyPage'

export default function MainShippingPolicyPage(){
    return(
        <>
        <ShippingPolicyPage/>
        </>
    )
}